// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2023-Present The Pepr Authors

import { Operation } from "kubernetes-fluent-client";
import { pino, destination as pinoDestination, stdTimeFunctions } from "pino";
import { Store } from "../k8s";

const isPrettyLog = process.env.PEPR_PRETTY_LOGS === "true";
const redactedValue = "**redacted**";

const pretty = {
  target: "pino-pretty",
  options: {
    colorize: true,
  },
};

// Pretty log mode uses pino-pretty as a worker-thread transport (already async).
// Default mode uses an async stdout destination so sustained log volume does not
// block the event loop when the container log pipe backpressures.
const destination = isPrettyLog ? undefined : pinoDestination({ sync: false });
const transport = isPrettyLog ? pretty : undefined;
// epochTime is the pino default
const pinoTimeFunction =
  process.env.PINO_TIME_STAMP === "iso"
    ? (): string => stdTimeFunctions.isoTime()
    : (): string => stdTimeFunctions.epochTime();
const Log = destination
  ? pino({ timestamp: pinoTimeFunction }, destination)
  : pino({ transport, timestamp: pinoTimeFunction });

if (process.env.LOG_LEVEL) {
  Log.level = process.env.LOG_LEVEL;
}

// Callers on graceful shutdown paths (e.g. SIGTERM) should invoke this before
// process.exit so the async buffer drains. Hard crashes may lose up to the
// buffered tail (~4KB) which is an accepted tradeoff for unblocking the loop.
export function flushLogsSync(): void {
  destination?.flushSync();
}

export function redactedStore(store: Store): Store {
  const redacted = process.env.PEPR_STORE_REDACT_VALUES === "true";
  return {
    ...store,
    data: Object.keys(store.data).reduce((acc: Record<string, string>, key: string) => {
      acc[key] = redacted ? redactedValue : store.data[key];
      return acc;
    }, {}),
  };
}

export function redactedPatch(patch: Record<string, Operation> = {}): Record<string, Operation> {
  const redacted = process.env.PEPR_STORE_REDACT_VALUES === "true";

  if (!redacted) {
    return patch;
  }

  const redactedCache: Record<string, Operation> = {};

  Object.entries(patch).forEach(([key, operation]) => {
    const isRedacted = key.includes(":");
    const targetKey = isRedacted ? `${key.substring(0, key.lastIndexOf(":"))}:**redacted**` : key;

    const redactedOperation = isRedacted
      ? {
          ...operation,
          ...(Object.hasOwn(operation, "value") ? { value: redactedValue } : {}),
        }
      : operation;

    redactedCache[targetKey] = redactedOperation;
  });

  return redactedCache;
}

export default Log;
