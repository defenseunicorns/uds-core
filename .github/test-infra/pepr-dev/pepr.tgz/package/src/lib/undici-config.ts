// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2023-Present The Pepr Authors

import { Agent, setGlobalDispatcher } from "undici";
import Log from "./telemetry/logger";

let configured = false;

/**
 * Configure undici's global dispatcher with tight timeouts so that K8s API
 * calls fail fast when the underlying socket dies silently (e.g. apiserver
 * pod rolled, konnectivity tunnel dropped, HCP churn). Without these, a
 * fetch can hang tens of seconds to minutes waiting on a dead TCP connection
 * before throwing, eating retry budgets in downstream operators.
 *
 * Values can be overridden via env vars for testing.
 */
export function configureUndici(): void {
  if (configured) return;
  configured = true;

  const connectTimeoutMs = parseInt(process.env.PEPR_UNDICI_CONNECT_TIMEOUT_MS ?? "10000", 10);
  const headersTimeoutMs = parseInt(process.env.PEPR_UNDICI_HEADERS_TIMEOUT_MS ?? "15000", 10);
  const bodyTimeoutMs = parseInt(process.env.PEPR_UNDICI_BODY_TIMEOUT_MS ?? "30000", 10);
  const keepAliveTimeoutMs = parseInt(process.env.PEPR_UNDICI_KEEP_ALIVE_TIMEOUT_MS ?? "10000", 10);

  try {
    setGlobalDispatcher(
      new Agent({
        connect: { timeout: connectTimeoutMs },
        headersTimeout: headersTimeoutMs,
        bodyTimeout: bodyTimeoutMs,
        keepAliveTimeout: keepAliveTimeoutMs,
      }),
    );
    Log.info(
      { connectTimeoutMs, headersTimeoutMs, bodyTimeoutMs, keepAliveTimeoutMs },
      "Configured undici global dispatcher",
    );
  } catch (err) {
    Log.warn({ err }, "Failed to configure undici global dispatcher");
  }
}
