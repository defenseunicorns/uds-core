// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2023-Present The Pepr Authors

import { execSync } from "child_process";
import fs from "fs";
import { resolve } from "path";
import prompt from "prompts";

import {
  codeSettings,
  helloPepr,
  prettier,
  samplesYaml,
  snippet,
  tsConfig,
} from "../init/templates";
import { write } from "../init/utils";
import { Command } from "commander";
import Log from "../../lib/telemetry/logger";

export default function (program: Command): void {
  program
    .command("update")
    .description("Update this Pepr module. Not recommended for prod as it may change files.")
    .option("-s, --skip-template-update", "Do not update template files")
    .option("-y, --yes", "Skip confirmation prompt")
    .action(async opts => {
      if (!opts.skipTemplateUpdate && !opts.yes) {
        const { confirm } = await prompt({
          type: "confirm",
          name: "confirm",
          message:
            "This will overwrite previously auto-generated files including the capabilities/HelloPepr.ts file.\n" +
            "Are you sure you want to continue?",
        });

        // If the user doesn't confirm, exit
        if (!confirm) {
          return;
        }
      }

      Log.info("Updating the Pepr module...");

      try {
        // Update Pepr for the module
        execSync("npm install pepr@latest", {
          stdio: "pipe",
        });

        // Don't update the template files if the user specified the --skip-template-update flag
        if (!opts.skipTemplateUpdate) {
          execSync("npx pepr update-templates", {
            stdio: "pipe",
          });
        }

        Log.info(`✅ Module updated successfully`);
      } catch (error) {
        Log.error(error, `Error updating Pepr module:`);
        process.exitCode = 1;
      }
    });

  program
    .command("update-templates", { hidden: true })
    .description("Perform template updates")
    .action(async opts => {
      Log.info("Updating Pepr config and template files...");

      try {
        // Don't update the template files if the user specified the --skip-template-update flag
        if (!opts.skipTemplateUpdate) {
          await write(resolve(prettier.path), prettier.data);
          await write(resolve(tsConfig.path), tsConfig.data);
          await write(resolve(".vscode", snippet.path), snippet.data);
          await write(resolve(".vscode", codeSettings.path), codeSettings.data);

          // Update the samples.yaml file if it exists
          const samplePath = resolve("capabilities", samplesYaml.path);
          if (fs.existsSync(samplePath)) {
            fs.unlinkSync(samplePath);
            await write(samplePath, samplesYaml.data);
          }

          // Update the HelloPepr.ts file if it exists
          const tsPath = resolve("capabilities", helloPepr.path);
          if (fs.existsSync(tsPath)) {
            await write(tsPath, helloPepr.data);
          }
        }
      } catch (error) {
        Log.error(error, `Error updating template files:`);
        process.exitCode = 1;
      }
    });
}
